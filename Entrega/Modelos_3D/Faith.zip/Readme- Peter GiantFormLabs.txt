
Hi, thank you for downloading this model.  

You can also take a look at the other models we offer. 
We have several full character models, fully textured, some including normal maps, starting as low as $2 !(yes you read that right) These prices are only for a limited time.  

We hope the model you have downloaded proves to be of good use to you!

Kind regards,
& take care!
Peter.
GiantFormLabs.

